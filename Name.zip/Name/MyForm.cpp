#include "MyForm.h"
using namespace System;
using namespace System::Windows::Forms;
using namespace Name;
[STAThreadAttribute]
void Main(array<String^> ^ args) {
    Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Name::MyForm form;
	Application::Run(% form);
}
System::Void MyForm::ClearAll()
{
	txtOutput->Text = "";
	errorProvider1->SetError(txtInput1, "");
	errorProvider1->SetError(txtOutput, "");
}
System::Void MyForm::Dlt(long long n, long long x)
{
	if (n > 25000)
		errorProvider1->SetError(txtOutput, "������������ �����");
	else if (n != 1)
	{
		if (!(n % x))
		{
			txtOutput->Text += x.ToString() + ", ";
			Dlt(n / x, x);
		}
		else
		{
			x++;
			Dlt(n, x);
		}
	}
}

System::Void MyForm::btnCalculate_Click(System::Object^ sender, System::EventArgs^ e) {
	ClearAll();
	long long n;
	bool result = Int64::TryParse(this->txtInput1->Text, n);
	if (result && n > 0)
	{
		Dlt(n, 2);
		txtOutput->Text->TrimEnd(new wchar_t[]{ ',', ' ' });
	}
	else if (!result)
	{
		errorProvider1->SetError(txtInput1, "n �� ����� �����");
	}
	else if (n < 0)
	{
		errorProvider1->SetError(txtInput1, "������������� �����");
	}
	
}